﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace informatsystemaptekKURCOVAIA
{
    /// <summary>
    /// Логика взаимодействия для Zakasi.xaml
    /// </summary>
    public partial class Zakasi : Window
    {
        public Zakasi()
        {
            InitializeComponent();
            LoadData();
        }

        private void NasadLekarstvoButton_Click(object sender, RoutedEventArgs e)
        {
            NachWindow nachWindow = new NachWindow();
            nachWindow.Show();
            this.Close();
        }

        private void ObnovitButton_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        public void LoadData()
        {
            try
            {
                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string query = $"SELECT TOP (1000) [ID], [ID Лекарства], [ID Сотрудника], [Фамилия клиента], [Имя клиента], [Номер телефона клиента], [Цена лекарства] FROM [Apteka].[dbo].[Zakasi]";

                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();

                SqlDataAdapter adapter = new SqlDataAdapter(command);

                DataTable dt_attendance = new DataTable();

                dt_attendance.NewRow();

                adapter.Fill(dt_attendance);

                ZakasiDataGrid.ItemsSource = dt_attendance.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DOBZakasiButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int idzakasi = Convert.ToInt32(ZakasiIDDOB.Text);
                int idlekarstv = Convert.ToInt32(ZakasiIDLekarstaDOB.Text);
                int idsotrydnik = Convert.ToInt32(ZakasiIDSotrydDOB.Text);
                string famklient = Convert.ToString(ZakasiFamKlDOB.Text);
                string nameklient = Convert.ToString(ZakasiNameKlDOB.Text);
                string numbertelkl = Convert.ToString(ZakasiNumbertelDOB.Text);
                string tcenalekarctv = Convert.ToString(ZakasiTsenaLekDOB.Text);

                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString); // Подключение к БД
                connection.Open();// Открытие Соединения*/
                string cmdTxt = $"INSERT INTO Zakasi (ID, [ID Лекарства], [ID Сотрудника], [Фамилия клиента], [Имя клиента], [Номер телефона клиента], [Цена лекарства] ) VALUES ('{idzakasi}', '{idlekarstv}', '{idsotrydnik}', '{famklient}', '{nameklient}', '{numbertelkl}', '{tcenalekarctv}')";
                SqlCommand command = new SqlCommand(cmdTxt, connection); // Объект вывода запросов
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!\nВставлено объектов: " + number, "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                ZakasiIDDOB.Clear(); ZakasiIDLekarstaDOB.Clear(); ZakasiIDSotrydDOB.Clear(); ZakasiFamKlDOB.Clear(); ZakasiNameKlDOB.Clear(); ZakasiNumbertelDOB.Clear(); ZakasiTsenaLekDOB.Clear();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                ZakasiIDDOB.Clear(); ZakasiIDLekarstaDOB.Clear(); ZakasiIDSotrydDOB.Clear(); ZakasiFamKlDOB.Clear(); ZakasiNameKlDOB.Clear(); ZakasiNumbertelDOB.Clear(); ZakasiTsenaLekDOB.Clear();

            }
        }

        private void ZakasiIdButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int oldidzakasi = Convert.ToInt32(ZakasiIDISM.Text);
                int newidzakasi = Convert.ToInt32(ZakasiIDISM_Copy.Text);
                string ssql = $"UPDATE Zakasi SET ID = '{newidzakasi}' WHERE ID = '{oldidzakasi}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                ZakasiIDISM.Clear(); ZakasiIDISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                ZakasiIDISM.Clear(); ZakasiIDISM_Copy.Clear();
            }
        }

        private void ZakasiIDLekButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int oldidlekarstv = Convert.ToInt32(ZakasiIDLekarstaISM.Text);
                int newidlekarstv = Convert.ToInt32(ZakasiIDLekarstaISM_Copy.Text);
                string ssql = $"UPDATE Zakasi SET [ID Лекарства] = '{newidlekarstv}' WHERE [ID Лекарства] = '{oldidlekarstv}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                ZakasiIDLekarstaISM.Clear(); ZakasiIDLekarstaISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                ZakasiIDLekarstaISM.Clear(); ZakasiIDLekarstaISM_Copy.Clear();
            }
        }

        private void ZakasiIDSoutrydnikaButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int oldidsotrydnik = Convert.ToInt32(ZakasiIDSotrydISM.Text);
                int newidsotrydnik = Convert.ToInt32(ZakasiIDSotrydISM_Copy.Text);
                string ssql = $"UPDATE Zakasi SET [ID Сотрудника] = '{newidsotrydnik}' WHERE [ID Сотрудника] = '{oldidsotrydnik}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                ZakasiIDSotrydISM.Clear(); ZakasiIDSotrydISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                ZakasiIDSotrydISM.Clear(); ZakasiIDSotrydISM_Copy.Clear();
            }
        }

        private void ZakasiFamKlButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string oldfamklient = Convert.ToString(ZakasiFamKlISM.Text);
                string newfamklient = Convert.ToString(ZakasiFamKlISM_Copy.Text);
                string ssql = $"UPDATE Zakasi SET [Фамилия клиента] = '{newfamklient}' WHERE [Фамилия клиента] = '{oldfamklient}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                ZakasiFamKlISM.Clear(); ZakasiFamKlISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                ZakasiFamKlISM.Clear(); ZakasiFamKlISM_Copy.Clear();
            }
        }

        private void ZakasiNameKlButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string oldnameklient = Convert.ToString(ZakasiNameKlISM.Text);
                string newnameklient = Convert.ToString(ZakasiNameKlISM_Copy.Text);
                string ssql = $"UPDATE Zakasi SET [Имя клиента] = '{newnameklient}' WHERE [Имя клиента] = '{oldnameklient}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                ZakasiNameKlISM.Clear(); ZakasiNameKlISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                ZakasiNameKlISM.Clear(); ZakasiNameKlISM_Copy.Clear();
            }
        }

        private void ZakasiNumbertelklButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string oldnumbertelkl = Convert.ToString(ZakasiNumbertelISM.Text);
                string newnumbertelkl = Convert.ToString(ZakasiNumbertelISM_Copy.Text);
                string ssql = $"UPDATE Zakasi SET [Номер телефона клиента] = '{newnumbertelkl}' WHERE [Номер телефона клиента] = '{oldnumbertelkl}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                ZakasiNumbertelISM.Clear(); ZakasiNumbertelISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                ZakasiNumbertelISM.Clear(); ZakasiNumbertelISM_Copy.Clear();
            }
        }

        private void ZakasiTcenaLekButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string oldtcenalekarctv = Convert.ToString(ZakasiTsenaLekISM.Text);
                string newtcenalekarctv = Convert.ToString(ZakasiTsenaLekISM_Copy.Text);
                string ssql = $"UPDATE Zakasi SET [Цена лекарства] = '{newtcenalekarctv}' WHERE [Цена лекарства] = '{oldtcenalekarctv}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                ZakasiTsenaLekISM.Clear(); ZakasiTsenaLekISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                ZakasiTsenaLekISM.Clear(); ZakasiTsenaLekISM_Copy.Clear();
            }
        }

        private void DELETEIDZakasi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int idd = Convert.ToInt32(ZakasiDELETEID.Text);

                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = new SqlCommand($"DELETE FROM Zakasi WHERE ID = '{idd}'", connection);
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!\nУдалено объектов: " + number, "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                ZakasiDELETEID.Clear();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                ZakasiDELETEID.Clear();
            }
        }
    }
}
