﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace informatsystemaptekKURCOVAIA
{
    /// <summary>
    /// Логика взаимодействия для NachWindow.xaml
    /// </summary>
    public partial class NachWindow : Window
    {
        public NachWindow()
        {
            InitializeComponent();
        }

        private void SpisokLekarctvButton_Click(object sender, RoutedEventArgs e)
        {
            CpiisokLekarctv cpiisokLekarctv = new CpiisokLekarctv();
            cpiisokLekarctv.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)//Закрыть окно
        {
            this.Close();
        }

        private void SoutrydnikiButton_Click(object sender, RoutedEventArgs e)
        {
            CpiisokSoutrydnik cpiisokSoutrydnik = new CpiisokSoutrydnik();
            cpiisokSoutrydnik.Show();
            this.Close();
        }

        private void PolzovateliButton_Click(object sender, RoutedEventArgs e)
        {
            CpiisokPolzovatel cpiisokPolzovatel = new CpiisokPolzovatel();
            cpiisokPolzovatel.Show();
            this.Close();
        }

        private void ZakasiButton_Click(object sender, RoutedEventArgs e)
        {
            Zakasi zakasi = new Zakasi();
            zakasi.Show();
            this.Close();
        }

        private void NasadddButton_Click(object sender, RoutedEventArgs e)
        {
            Soutrydnik soutrydnik = new Soutrydnik();
            soutrydnik.Show();
            this.Close();
        }
    }
}
