﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace informatsystemaptekKURCOVAIA
{
    /// <summary>
    /// Логика взаимодействия для CpiisokSoutrydnik.xaml
    /// </summary>
    public partial class CpiisokSoutrydnik : Window
    {
        public CpiisokSoutrydnik()
        {
            InitializeComponent();
            LoadData();
        }

        public void LoadData()
        {
            try
            {
                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string query = $"SELECT TOP (1000) [id], [Фамилия], [Имя], [Отчество], [Номер телефона], [Должность], [Пароль] FROM [Apteka].[dbo].[Sotrudnik]";

                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();

                SqlDataAdapter adapter = new SqlDataAdapter(command);

                DataTable dt_attendance = new DataTable();

                dt_attendance.NewRow();

                adapter.Fill(dt_attendance);

                SotrydnikiDataGrid1.ItemsSource = dt_attendance.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void ObnovitButton_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
        }
        private void NasadLekarstvoButton_Click(object sender, RoutedEventArgs e)
        {
            NachWindow nachWindow = new NachWindow();
            nachWindow.Show();
            this.Close();
        }

        private void DOBOKBUTTON_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int idsoutrydnik1 = Convert.ToInt32(IDSoutrydnikDOB1.Text);
                string fam1 = Convert.ToString(FamDOB1.Text);
                string name1 = Convert.ToString(NameDOB1.Text);
                string otchectvo1 = Convert.ToString(OtchectvoDOB1.Text);
                string numbertel1 = Convert.ToString(NumberTelDOB1.Text);
                string dolschost1 = Convert.ToString(DolshnostDOB1.Text);
                string password1 = Convert.ToString(PasswordDOB1.Text);
                


                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString); // Подключение к БД
                connection.Open();// Открытие Соединения*/
                string cmdTxt = $"INSERT INTO Sotrudnik (id, Фамилия, Имя, Отчество, [Номер телефона], Должность, Пароль ) VALUES ('{idsoutrydnik1}', '{fam1}', '{name1}', '{otchectvo1}', '{numbertel1}', '{dolschost1}', '{password1}')";
                SqlCommand command = new SqlCommand(cmdTxt, connection); // Объект вывода запросов
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!\nВставлено объектов: " + number, "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                IDSoutrydnikDOB1.Clear(); FamDOB1.Clear(); NameDOB1.Clear(); OtchectvoDOB1.Clear(); NumberTelDOB1.Clear(); DolshnostDOB1.Clear(); PasswordDOB1.Clear();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                IDSoutrydnikDOB1.Clear(); FamDOB1.Clear(); NameDOB1.Clear(); OtchectvoDOB1.Clear(); NumberTelDOB1.Clear(); DolshnostDOB1.Clear(); PasswordDOB1.Clear();

            }
        }

        private void IDSoutrydnikISMButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int oldid1 = Convert.ToInt32(IDSoutrydnikISM.Text);
                int newid1 = Convert.ToInt32(IDSoutrydnikISM_Copy.Text);
                string ssql = $"UPDATE Sotrudnik SET id = '{newid1}' WHERE id = '{oldid1}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                IDSoutrydnikISM.Clear(); IDSoutrydnikISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                IDSoutrydnikISM.Clear(); IDSoutrydnikISM_Copy.Clear();
            }

        }

        private void FamISMButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string oldfam1 = Convert.ToString(FamISM.Text);
                string newfam1 = Convert.ToString(FamISM_Copy.Text);
                string ssql = $"UPDATE Sotrudnik SET Фамилия = '{newfam1}' WHERE Фамилия = '{oldfam1}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                FamISM.Clear(); FamISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                FamISM.Clear(); FamISM_Copy.Clear();
            }
        }

        private void NameISMButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string oldname1 = Convert.ToString(NameISM.Text);
                string newname1 = Convert.ToString(NameISM_Copy.Text);
                string ssql = $"UPDATE Sotrudnik SET Имя = '{newname1}' WHERE Имя = '{oldname1}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                NameISM.Clear(); NameISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                NameISM.Clear(); NameISM_Copy.Clear();
            }

        }
        private void OtchectvoISMButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string oldotchectvo1 = Convert.ToString(OtchectvoISM.Text);
                string newotchectvo1 = Convert.ToString(OtchectvoISM_Copy.Text);
                string ssql = $"UPDATE Sotrudnik SET Отчество = '{newotchectvo1}' WHERE Отчество = '{oldotchectvo1}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                OtchectvoISM.Clear(); OtchectvoISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                OtchectvoISM.Clear(); OtchectvoISM_Copy.Clear();
            }

        }
        private void NumberTelISMButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string oldnumbertel1 = Convert.ToString(NumberTel.Text);
                string newnumbertel1 = Convert.ToString(NumberTel_Copy.Text);
                string ssql = $"UPDATE Sotrudnik SET [Номер телефона] = '{newnumbertel1}' WHERE [Номер телефона] = '{oldnumbertel1}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                NumberTel.Clear(); NumberTel_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                NumberTel.Clear(); NumberTel_Copy.Clear();
            }

        }
        private void DolshnostISMButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string olddolschost1 = Convert.ToString(DolshnostISM.Text);
                string newdolschost1 = Convert.ToString(DolshnostISM_Copy.Text);
                string ssql = $"UPDATE Sotrudnik SET Должность = '{newdolschost1}' WHERE Должность = '{olddolschost1}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                DolshnostISM.Clear(); DolshnostISM_Copy.Clear();
            }
             catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                DolshnostISM.Clear(); DolshnostISM_Copy.Clear();
            }

        }

        private void PasswordISMButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string oldpassword1 = Convert.ToString(PasswordISM.Text);
                string newpassword1 = Convert.ToString(PasswordISM_Copy.Text);
                string ssql = $"UPDATE Sotrudnik SET Пароль = '{newpassword1}' WHERE Пароль = '{oldpassword1}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                PasswordISM.Clear(); PasswordISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                PasswordISM.Clear(); PasswordISM_Copy.Clear();
            }
        }

        private void ISDELETEBUTTON_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int idd1 = Convert.ToInt32(DELETEID.Text);

                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = new SqlCommand($"DELETE FROM Sotrudnik WHERE id = '{idd1}'", connection);
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!\nУдалено объектов: " + number, "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                DELETEID.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                DELETEID.Clear();
            }
        }
    }
}
