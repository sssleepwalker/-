﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace informatsystemaptekKURCOVAIA
{
    /// <summary>
    /// Логика взаимодействия для NachEkranPOl.xaml
    /// </summary>
    public partial class NachEkranPOl : Window
    {
        public NachEkranPOl()
        {
            InitializeComponent();
            LoadData();
        }

        private void NazadBuTtON_Click(object sender, RoutedEventArgs e)
        {
            Polsovatel polsovatel = new Polsovatel();
            polsovatel.Show();
            this.Close();
        }

        private void ViitiButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        public void LoadData()
        {
            try
            {
                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string query = $"SELECT TOP (1000) [id], [Название лекарства], [Производитель], [Форма выпуска], [Условия хранения], [Активное вещество], [Дозировка], [Срок годности], [Количество] FROM [Apteka].[dbo].[Lekarstvo]";

                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();

                SqlDataAdapter adapter = new SqlDataAdapter(command);

                DataTable dt_attendance = new DataTable();

                dt_attendance.NewRow();

                adapter.Fill(dt_attendance);

                LekarstvaCpisok.ItemsSource = dt_attendance.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
