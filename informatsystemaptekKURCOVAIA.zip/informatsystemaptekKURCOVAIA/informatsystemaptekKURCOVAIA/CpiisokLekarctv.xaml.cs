﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace informatsystemaptekKURCOVAIA
{
    /// <summary>
    /// Логика взаимодействия для CpiisokLekarctv.xaml
    /// </summary>
    public partial class CpiisokLekarctv : Window
    {
        public CpiisokLekarctv()
        {
            InitializeComponent();
            LoadData();
        }

        public void LoadData()//Загрузка данных
        {
            try
            {
                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string query = $"SELECT TOP (1000) [id], [Название лекарства], [Производитель], [Форма выпуска], [Условия хранения], [Активное вещество], [Дозировка], [Срок годности], [Количество], [Цена] FROM [Apteka].[dbo].[Lekarstvo]";

                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();

                SqlDataAdapter adapter = new SqlDataAdapter(command);

                DataTable dt_attendance = new DataTable();

                dt_attendance.NewRow();

                adapter.Fill(dt_attendance);

                CpisokLekarstv.ItemsSource = dt_attendance.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void LekDobavitButton_Click(object sender, RoutedEventArgs e)// Добавление
        {
            try
            {
                int id = Convert.ToInt32(IDLekarstvoDOB.Text);
                string namelekarstvo = Convert.ToString(NameLekarstvaDOB.Text);
                string proisvoditel = Convert.ToString(ProizvoditelDOB.Text);
                string formavipysk = Convert.ToString(FormaVipyskDOB.Text);
                string ycloviaxr = Convert.ToString(YcliviaXrDOB.Text);
                string aktivnoevesh = Convert.ToString(AktivnoeVeshDOB.Text);
                string dozirovka = Convert.ToString(DozirovkaDOB.Text);
                string crokgodnosti = Convert.ToString(CrokGodnocti.Text);
                string kollichectvo = Convert.ToString(KolichectvoDOB.Text);
                string tcena = Convert.ToString(TcenaDOB.Text);


                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString); // Подключение к БД
                connection.Open();// Открытие Соединения*/
                string cmdTxt = $"INSERT INTO Lekarstvo (id, [Название лекарства], Производитель, [Форма выпуска], [Условия хранения], [Активное вещество], Дозировка, [Срок годности], Количество, Цена ) VALUES ('{id}', '{namelekarstvo}', '{proisvoditel}', '{formavipysk}', '{ycloviaxr}', '{aktivnoevesh}', '{dozirovka}', '{crokgodnosti}', '{kollichectvo}', '{tcena}')";
                SqlCommand command = new SqlCommand(cmdTxt, connection); // Объект вывода запросов
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!\nВставлено объектов: " + number, "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                IDLekarstvoDOB.Clear(); NameLekarstvaDOB.Clear(); ProizvoditelDOB.Clear(); FormaVipyskDOB.Clear(); YcliviaXrDOB.Clear(); AktivnoeVeshDOB.Clear(); DozirovkaDOB.Clear(); CrokGodnocti.Clear(); KolichectvoDOB.Clear(); TcenaDOB.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                IDLekarstvoDOB.Clear(); NameLekarstvaDOB.Clear(); ProizvoditelDOB.Clear(); FormaVipyskDOB.Clear(); YcliviaXrDOB.Clear(); AktivnoeVeshDOB.Clear(); DozirovkaDOB.Clear(); CrokGodnocti.Clear(); KolichectvoDOB.Clear(); TcenaDOB.Clear();
            }
        }

        private void NasadLekarstvoButton_Click(object sender, RoutedEventArgs e)//Назад
        {
            NachWindow nachWindow = new NachWindow();
            nachWindow.Show();
            this.Close();
        }

        private void ObnovitButton_Click(object sender, RoutedEventArgs e)//Обновить таблицу
        {
            LoadData();
        }

        private void IDismButton_Click(object sender, RoutedEventArgs e)//ИЗМЕНЕНИЯ НОМЕРА АЙДИ
        {
            try
            {
                int oldid = Convert.ToInt32(IDLekarstvoISM.Text);
                int newid = Convert.ToInt32(IDLekarstvoISM_Copy.Text);
                string ssql = $"UPDATE Lekarstvo SET id = '{newid}' WHERE id = '{oldid}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                IDLekarstvoISM.Clear(); IDLekarstvoISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                IDLekarstvoISM.Clear(); IDLekarstvoISM_Copy.Clear();
            }

        }

        private void NameLekarstvaOkButton_Click(object sender, RoutedEventArgs e)//ИЗМЕНЕНИЕ НАЗВАНИЯ ЛЕКАРСТВА
        {
            try
            {
                string oldnamelekarstvo = Convert.ToString(NameLekarstvaISM.Text);
                string newnamelekarstvo = Convert.ToString(NameLekarstvaISM_Copy.Text);
                string ssql = $"UPDATE Lekarstvo SET [Название лекарства] = '{newnamelekarstvo}' WHERE [Название лекарства] = '{oldnamelekarstvo}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                NameLekarstvaISM.Clear(); NameLekarstvaISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                NameLekarstvaISM.Clear(); NameLekarstvaISM_Copy.Clear();
            }
        }

        private void ProizvoditelOKButton_Click(object sender, RoutedEventArgs e)//ИЗМЕНЕНИЕ ПРОИЗВОДИТЕЛЯ
        {
            try
            {

                string oldproisvoditel = Convert.ToString(ProizvoditelISM.Text);
                string newproisvoditel = Convert.ToString(ProizvoditelISM_Copy.Text);
                string ssql = $"UPDATE Lekarstvo SET Производитель = '{newproisvoditel}' WHERE Производитель = '{oldproisvoditel}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                ProizvoditelISM.Clear(); ProizvoditelISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                ProizvoditelISM.Clear(); ProizvoditelISM_Copy.Clear();
            }
        }

        private void ForvipyskOKButton_Click(object sender, RoutedEventArgs e)//ИЗМЕНЕНИЕ ФОРМЫ ВЫПУСКА
        {
            try
            {
                string oldformavipysk = Convert.ToString(FormaVipyskISM.Text);
                string newformavipysk = Convert.ToString(FormaVipyskISM_Copy.Text);
                string ssql = $"UPDATE Lekarstvo SET [Форма выпуска] = '{newformavipysk}' WHERE [Форма выпуска] = '{oldformavipysk}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                FormaVipyskISM.Clear(); FormaVipyskISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                FormaVipyskISM.Clear(); FormaVipyskISM_Copy.Clear();
            }
        }

        private void YclxrnOKButton_Click(object sender, RoutedEventArgs e)//ИЗМЕНЕНИЯ УСЛОВИЯ ХРАНЕНИЯ
        {
            try
            {
                string oldycloviaxr = Convert.ToString(YcloviaXranISM.Text);
                string newycloviaxr = Convert.ToString(YcloviaXranISM_Copy.Text);
                string ssql = $"UPDATE Lekarstvo SET [Условия хранения] = '{newycloviaxr}' WHERE [Условия хранения] = '{oldycloviaxr}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                YcloviaXranISM.Clear(); YcloviaXranISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                YcloviaXranISM.Clear(); YcloviaXranISM_Copy.Clear();
            }
        }

        private void AktveshOKButton_Click(object sender, RoutedEventArgs e)//ИЗМЕНЕНИЕ АКТИВНОГО ВЕЩЕСТВА
        {
            try
            {
                string oldaktivnoevesh = Convert.ToString(AktivnoeVeshISM.Text);
                string newaktivnoevesh = Convert.ToString(AktivnoeVeshISM_Copy.Text);
                string ssql = $"UPDATE Lekarstvo SET [Активное вещество] = '{newaktivnoevesh}' WHERE [Активное вещество] = '{oldaktivnoevesh}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                AktivnoeVeshISM.Clear(); AktivnoeVeshISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                AktivnoeVeshISM.Clear(); AktivnoeVeshISM_Copy.Clear();
            }
        }

        private void DozirovkaOKButton_Click(object sender, RoutedEventArgs e)//ИЗМЕНЕНИЕ ДОЗИРОВКИ
        {
            try
            {
                string olddozirovka = Convert.ToString(DosirovkaISM.Text);
                string newdozirovka = Convert.ToString(DosirovkaISM_Copy.Text);
                string ssql = $"UPDATE Lekarstvo SET Дозировка = '{newdozirovka}' WHERE Дозировка = '{olddozirovka}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                DosirovkaISM.Clear(); DosirovkaISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                DosirovkaISM.Clear(); DosirovkaISM_Copy.Clear();
            }
        }

        private void CrodgodOKButton_Click(object sender, RoutedEventArgs e)//ИЗМЕНЕНИЕ СРОКА ГОДНОСТИ
        {
            try
            {
                string oldcrokgodnosti = Convert.ToString(CrokGodnoctiISM1.Text);
                string newcrokgodnosti = Convert.ToString(CrokGodnoctiISM1_Copy.Text);
                string ssql = $"UPDATE Lekarstvo SET [Срок годности] = '{newcrokgodnosti}' WHERE [Срок годности] = '{oldcrokgodnosti}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                CrokGodnoctiISM1.Clear(); CrokGodnoctiISM1_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                CrokGodnoctiISM1.Clear(); CrokGodnoctiISM1_Copy.Clear();
            }
        }

        private void KolichOKButton_Click(object sender, RoutedEventArgs e)//ИЗМЕНЕНИЕ КОЛИЧЕСТВА
        {
            try
            {
                string oldkollichectvo = Convert.ToString(KolichectvoISM.Text);
                string newkollichectvo = Convert.ToString(KolichectvoISM_Copy.Text);
                string ssql = $"UPDATE Lekarstvo SET Количество = '{newkollichectvo}' WHERE Количество = '{oldkollichectvo}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                KolichectvoISM.Clear(); KolichectvoISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                KolichectvoISM.Clear(); KolichectvoISM_Copy.Clear();
            }
        }

        private void IDDELETEButton_Click(object sender, RoutedEventArgs e) //УДАЛЕНИЕ ПО ID
        {
            try
            {
                int id = Convert.ToInt32(IDdelete.Text);

                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = new SqlCommand($"DELETE FROM Lekarstvo WHERE id = '{id}'", connection);
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!\nУдалено объектов: " + number, "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                IDdelete.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                IDdelete.Clear(); 
            }
        }

        private void TcenaISMButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string oldtcena = Convert.ToString(TcenaISM.Text);
                string newtcena = Convert.ToString(TcenaISM_Copy.Text);
                string ssql = $"UPDATE Lekarstvo SET Цена = '{newtcena}' WHERE Цена = '{oldtcena}'";

                string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                TcenaISM.Clear(); TcenaISM_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                TcenaISM.Clear(); TcenaISM_Copy.Clear();
            }
        }
    }
}
