﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace informatsystemaptekKURCOVAIA
{
    /// <summary>
    /// Логика взаимодействия для Registraia.xaml
    /// </summary>
    public partial class Registraia : Window
    {
        public Registraia()
        {
            InitializeComponent();
            LoadData1();
        }

        private void Button_Click(object sender, RoutedEventArgs e)//Назад
        {
            Polsovatel polsovatel = new Polsovatel();
            polsovatel.Show();
            this.Close();
        }

        public void LoadData1()
        {
            try
            {
                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string query = $"SELECT TOP (1000) [Фамилия], [Имя], [Отчество], [Дата рождения], [Номер телефона], [Почта], [Пароль] FROM [Apteka].[dbo].[Polzovatell]";

                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();

                SqlDataAdapter adapter = new SqlDataAdapter(command);

                DataTable dt_attendance = new DataTable();

                dt_attendance.NewRow();

                adapter.Fill(dt_attendance);
               

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                string fam = Convert.ToString(FamTextBox.Text);
                string name = Convert.ToString(NameTextBox.Text);
                string otchectvo = Convert.ToString(OtchestvoTextBox.Text);
                string datar = Convert.ToString(DataRozTextBox.Text);
                string numbertel = Convert.ToString(NumberTelTextBox.Text);
                string email = Convert.ToString(EmailTextBox.Text);
                string password = Convert.ToString(PasswordTextBox.Text);


                
                string connectionString = @"Data Source = .\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security = True";
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();

                string ssql = $"INSERT INTO Polzovatell ([Фамилия], [Имя], [Отчество], [Дата рождения], [Номер телефона], [Почта], [Пароль]) VALUES ('{fam}', '{name}', '{otchectvo}', '{datar}','{numbertel}','{email}', '{password}') ";
                SqlCommand command = new SqlCommand(ssql, conn);
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Регистрация прошла успешно! \n Пожалуйста, перейдите в окно входа для дальнейшей авторизации\nВставлено объектов: " + number, "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);
                

                FamTextBox.Clear(); NameTextBox.Clear(); OtchestvoTextBox.Clear(); DataRozTextBox.Clear(); NumberTelTextBox.Clear(); EmailTextBox.Clear(); PasswordTextBox.Clear();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                FamTextBox.Clear(); NameTextBox.Clear(); OtchestvoTextBox.Clear(); DataRozTextBox.Clear(); NumberTelTextBox.Clear(); EmailTextBox.Clear(); PasswordTextBox.Clear();
            }
        }
        


    }
}
