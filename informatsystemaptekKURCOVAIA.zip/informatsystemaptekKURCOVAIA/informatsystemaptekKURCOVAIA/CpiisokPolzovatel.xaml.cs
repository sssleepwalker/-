﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace informatsystemaptekKURCOVAIA
{
    /// <summary>
    /// Логика взаимодействия для CpiisokPolzovatel.xaml
    /// </summary>
    public partial class CpiisokPolzovatel : Window
    {
        public CpiisokPolzovatel()
        {
            InitializeComponent();
            LoadData();
        }

        private void NasadLekarstvoButton_Click(object sender, RoutedEventArgs e)
        {
            NachWindow nachWindow = new NachWindow();
            nachWindow.Show();
            this.Close();
        }

        private void ObnovitButton_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        public void LoadData()
        {
            try
            {
                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string query = $"SELECT TOP (1000) [Фамилия], [Имя], [Отчество], [Дата рождения], [Номер телефона], [Почта], [Пароль] FROM [Apteka].[dbo].[Polzovatell]";

                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();

                SqlDataAdapter adapter = new SqlDataAdapter(command);

                DataTable dt_attendance = new DataTable();

                dt_attendance.NewRow();

                adapter.Fill(dt_attendance);

                PolzovatelDataGrid.ItemsSource = dt_attendance.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void PolFamDOBButon_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string oldfam2 = Convert.ToString(PolFamDOB.Text);
                string newfam2 = Convert.ToString(PolFamDOB_Copy.Text);
                string ssql = $"UPDATE Polzovatell SET Фамилия = '{newfam2}' WHERE Фамилия = '{oldfam2}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                PolFamDOB.Clear(); PolFamDOB_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                PolFamDOB.Clear(); PolFamDOB_Copy.Clear();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string oldname2 = Convert.ToString(PolNameDOB.Text);
                string newname2 = Convert.ToString(PolNameDOB_Copy.Text);
                string ssql = $"UPDATE Polzovatell SET Имя = '{newname2}' WHERE Имя = '{oldname2}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                PolNameDOB.Clear(); PolNameDOB_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                PolNameDOB.Clear(); PolNameDOB_Copy.Clear();
            }
        }

        private void PolOtchectvoDOBButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string oldotchectvo2 = Convert.ToString(PolOtchectvoDOB.Text);
                string newotchectvo2 = Convert.ToString(PolOtchectvoDOB_Copy.Text);
                string ssql = $"UPDATE Polzovatell SET Отчество = '{newotchectvo2}' WHERE Отчество = '{oldotchectvo2}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                PolOtchectvoDOB.Clear(); PolOtchectvoDOB_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                PolOtchectvoDOB.Clear(); PolOtchectvoDOB_Copy.Clear();
            }
        }

        private void PolDatarDOBButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string olddatar2 = Convert.ToString(PolDatarDOB.Text);
                string newdatar2 = Convert.ToString(PolDatarDOB_Copy.Text);
                string ssql = $"UPDATE Polzovatell SET [Дата рождения] = '{newdatar2}' WHERE [Дата рождения] = '{olddatar2}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                PolDatarDOB.Clear(); PolDatarDOB_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                PolDatarDOB.Clear(); PolDatarDOB_Copy.Clear();
            }

        }

        private void PolNumbertelDOBButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string oldnumbertel2 = Convert.ToString(PolNumbertelDOB.Text);
                string newnumbertel2 = Convert.ToString(PolNumbertelDOB_Copy.Text);
                string ssql = $"UPDATE Polzovatell SET [Номер телефона] = '{newnumbertel2}' WHERE [Номер телефона] = '{oldnumbertel2}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                PolNumbertelDOB.Clear(); PolNumbertelDOB_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                PolNumbertelDOB.Clear(); PolNumbertelDOB_Copy.Clear();
            }
        }

        private void PolEmailDOBButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string oldemail2 = Convert.ToString(PolEmailDOB.Text);
                string newemail2 = Convert.ToString(PolEmailDOB_Copy.Text);
                string ssql = $"UPDATE Polzovatell SET Почта = '{newemail2}' WHERE Почта = '{oldemail2}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                PolEmailDOB.Clear(); PolEmailDOB_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                PolEmailDOB.Clear(); PolEmailDOB_Copy.Clear();
            }
        }

        private void PolPasswordDOBButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string oldpassword2 = Convert.ToString(PolPasswordDOB.Text);
                string newpassword2 = Convert.ToString(PolPasswordDOB_Copy.Text);
                string ssql = $"UPDATE Polzovatell SET Пароль = '{newpassword2}' WHERE Пароль = '{oldpassword2}'";

                string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString); // Подключение к БД
                conn.Open();// Открытие Соединения*/

                SqlCommand command = new SqlCommand(ssql, conn);// Объект вывода запросов

                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены!\nОбновлено объектов: " + number);

                PolPasswordDOB.Clear(); PolPasswordDOB_Copy.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                PolPasswordDOB.Clear(); PolPasswordDOB_Copy.Clear();
            }
        }

        private void DeLeTeEmailButton1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string emaill = Convert.ToString(DeLeTeEmailButton.Text);

                string connectionString = @"Data Source =.\SQLEXPRESS; Initial Catalog = Apteka; Integrated Security = True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = new SqlCommand($"DELETE FROM Polzovatell WHERE Почта = '{emaill}'", connection);
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Изменения сохранены успешно!\nУдалено объектов: " + number, "Статус действия", MessageBoxButton.OK, MessageBoxImage.Information);

                DeLeTeEmailButton.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR!", MessageBoxButton.OK, MessageBoxImage.Error);
                DeLeTeEmailButton.Clear();
            }
        }
    }
}
